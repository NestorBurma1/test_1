class Person {
  final double latitude;
  final double longitude;
  final String firsName;
  final String lastName;
  final String pictureUrl;

  Person(this.latitude, this.longitude, this.firsName, this.lastName, this.pictureUrl);
  Person.fromJson(Map<String, dynamic> json)
      : firsName = json['name']['first'],
        lastName = json['name']['last'],
        latitude = json['location']['latitude'],
        longitude = json['location']['longitude'],
        pictureUrl = json['picture']['medium'];
}
