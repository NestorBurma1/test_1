import 'package:flutter/material.dart';
import 'package:test_1/model.dart';

class PersonContainer extends StatelessWidget {
  final Person person;

  PersonContainer({Key key, @required this.person})
      : assert(person != null),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(children: <Widget>[
      _showPerson(context, person),
      Image.network(person.pictureUrl)
    ]);
  }
}

Column _showPerson(BuildContext context, Person _person) {
  return Column(children: <Widget>[
    Image.network(_person.pictureUrl),
  ]);
}
